
  const BASEURL = 'http://localhost:8080';

  
export default BASEURL;